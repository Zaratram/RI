package encapsulamento;

/**
 * @author jorge
 */
public class Encapsulamento {

    public static void main(String[] args) {
        Pessoa
    }
}
