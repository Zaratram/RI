package encapsulamento;

/**
 *
 * @author jorge
 */
public class Pessoa {
    String nome;
    String cpf;
    int idade;
}
