package main;

public class Main {
    public static void main(String args[]) {
        Porta p1 = new Porta();
        p1.Abrir(Chave.getinstance());
        Porta p2 = new Porta();
        p2.Abrir(Chave.getinstance());
        Porta p3 = new Porta();
        p3.Abrir(Chave.getinstance());
    }
}

class Chave{
    private static Chave instance = null;

    private Chave(){

    }

    public static Chave getinstance(){
        if(instance == null)
            instance = new Chave();

        return instance;
    }
}

class Porta{

    public void Abrir(Chave chave){
        if(chave instanceof Chave)
            System.out.println("Abriu!!!");
    }
}